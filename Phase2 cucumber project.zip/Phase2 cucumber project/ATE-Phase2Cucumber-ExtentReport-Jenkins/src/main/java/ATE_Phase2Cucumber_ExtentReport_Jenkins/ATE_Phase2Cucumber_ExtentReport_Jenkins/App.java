package ATE_Phase2Cucumber_ExtentReport_Jenkins.ATE_Phase2Cucumber_ExtentReport_Jenkins;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
