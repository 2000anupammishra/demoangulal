package io.cucumber.junit;

public class CucumberOptions extends CucumberOptions {

}
