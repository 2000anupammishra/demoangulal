package junitTestScripts;

public class JavaOperations {

}
